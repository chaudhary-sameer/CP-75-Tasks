#include<iostream>
using namespace std;

int main() {
    int marks;
    cout << "Enter your marks (0-100): ";
    cin >> marks;
    
    if (marks >= 50) {
        cout << "Congratulations, you passed!" << endl;
    } else {
        cout << "Unfortunately, you failed." << endl;
    }
    
    return 0;
}
