#include<iostream>
using namespace std;

int main() {
    char alphabet;
    cout << "Enter a letter: ";
    cin >> alphabet;
    
    if (alphabet == 'a' || alphabet == 'e' || alphabet == 'i' || alphabet == 'o' || alphabet == 'u' ||
        alphabet == 'A' || alphabet == 'E' || alphabet == 'I' || alphabet == 'O' || alphabet == 'U') {
        cout << alphabet << " is a vowel." << endl;
    } else {
        cout << alphabet << " is a consonant." << endl;
    }
    
    return 0;
}
