#include<iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter an integer: ";
    cin >> num;
    switch (num % 2) {
        case 0: cout << num << " is Even"; break;
        case 1:
        case -1: cout << num << " is Odd"; break;
    }
    return 0;
}
