#include<iostream>
using namespace std;

int main() {
    int temperature;
    cout << "Enter current temperature: ";
    cin >> temperature;
    
    if (temperature > 30) {
        cout << "It is a hot day outside." << endl;
    }
    
    return 0;
}
