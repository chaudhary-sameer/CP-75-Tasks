#include<iostream>
using namespace std;

int main() {
    int pin;
    cout << "Enter your 4-digit PIN: ";
    cin >> pin;
    
    if (pin == 1234) {
        cout << "Access Granted." << endl;
    } else {
        cout << "Access Denied. Incorrect PIN." << endl;
    }
    
    return 0;
}
