#include<iostream>
using namespace std;

int main() {
    int number;
    cout << "Enter an integer: ";
    cin >> number;
    
    if (number < 0) {
        number = number * -1;
    }
    
    cout << "The absolute value is: " << number << endl;
    
    return 0;
}
