#include<iostream>
using namespace std;

int main() {
    int value;
    cout << "Enter a positive number: ";
    cin >> value;
    
    if (value % 2 == 0) {
        cout << value << " is divisible by 2." << endl;
    }
    
    if (value % 3 == 0) {
        cout << value << " is divisible by 3." << endl;
    }
    
    if (value % 5 == 0) {
        cout << value << " is divisible by 5." << endl;
    }
    
    return 0;
}
