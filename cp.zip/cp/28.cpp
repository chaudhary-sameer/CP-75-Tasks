#include<iostream>
using namespace std;

int main() {
    int choice;
    cout << "1. Balance\n2. Deposit\n3. Withdraw\nEnter choice: ";
    cin >> choice;
    switch (choice) {
        case 1: cout << "Checking balance..."; break;
        case 2: cout << "Processing deposit..."; break;
        case 3: cout << "Processing withdrawal..."; break;
        default: cout << "Invalid choice";
    }
    return 0;
}
