#include<iostream>
using namespace std;

int main() {
    int temp;
    cout << "Enter current temperature in Celsius: ";
    cin >> temp;

    if (temp >= 40) {
        cout << "Extreme heat! Stay hydrated." << endl;
    } else if (temp >= 30) {
        cout << "It's a hot day." << endl;
    } else if (temp >= 20) {
        cout << "Pleasant weather." << endl;
    } else if (temp >= 10) {
        cout << "It's getting chilly." << endl;
    } else {
        cout << "Cold weather! Wear a jacket." << endl;
    }
    
    return 0;
}
