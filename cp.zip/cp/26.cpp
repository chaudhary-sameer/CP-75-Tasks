#include<iostream>
using namespace std;

int main() {
    int score;
    cout << "Enter score (0-100): ";
    cin >> score;
    switch (score / 10) {
        case 10:
        case 9: cout << "Grade: A"; break;
        case 8: cout << "Grade: B"; break;
        case 7: cout << "Grade: C"; break;
        case 6: cout << "Grade: D"; break;
        default:
            if (score >= 0 && score < 60) cout << "Grade: F";
            else cout << "Invalid score";
    }
    return 0;
}
