#include<iostream>
using namespace std;

int main() {
    int speed;
    cout << "Enter current vehicle speed in km/h: ";
    cin >> speed;

    if (speed <= 60) {
        cout << "Safe city driving speed." << endl;
    } else if (speed <= 90) {
        cout << "Cruising speed." << endl;
    } else if (speed <= 120) {
        cout << "Highway limit reached. Drive carefully." << endl;
    } else {
        cout << "Warning: Overspeeding!" << endl;
    }
    
    return 0;
}
