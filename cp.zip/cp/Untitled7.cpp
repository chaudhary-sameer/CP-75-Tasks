#include<iostream>
using namespace std;

int main() {
    double totalAmount;
    int isMember, hasCoupon;
    double discount = 0.0;

    cout << "Enter total purchase amount: $";
    cin >> totalAmount;

    cout << "Are you a member? (1 for Yes, 0 for No): ";
    cin >> isMember;

    cout << "Do you have a coupon? (1 for Yes, 0 for No): ";
    cin >> hasCoupon;

    if (totalAmount >= 100.0) {
        discount = discount + 10.0;
        cout << "- Applied $10 bulk discount." << endl;
    }

    if (isMember == 1) {
        discount = discount + 5.0;
        cout << "- Applied $5 member discount." << endl;
    }

    if (hasCoupon == 1) {
        if (totalAmount > 50.0) {
            discount = discount + 15.0;
            cout << "- Applied $15 special coupon." << endl;
        }
    }

    double finalPrice = totalAmount - discount;
    
    if (finalPrice < 0) {
        finalPrice = 0; 
    }

    cout << "Total Discount: $" << discount << endl;
    cout << "Final Price: $" << finalPrice << endl;

    return 0;
}
