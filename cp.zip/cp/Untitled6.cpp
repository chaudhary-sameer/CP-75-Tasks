#include<iostream>
using namespace std;

int main() {
    int hasIDCard, hasClearance, clearanceLevel;
    
    cout << "Do you have an ID card? (1 for Yes, 0 for No): ";
    cin >> hasIDCard;
    
    cout << "Do you have security clearance? (1 for Yes, 0 for No): ";
    cin >> hasClearance;
    
    cout << "Enter your clearance level (1-5): ";
    cin >> clearanceLevel;
    
    if (hasIDCard == 1) {
        if (hasClearance == 1) {
            if (clearanceLevel >= 3) {
                cout << "Access granted to the server room." << endl;
            }
        }
    }
    
    if (hasIDCard == 0) {
        cout << "Access denied: Missing ID Card." << endl;
    }
    
    return 0;
}
