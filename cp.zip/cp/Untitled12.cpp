#include<iostream>
using namespace std;

int main() {
    int number;
    cout << "Enter a number: ";
    cin >> number;
    
    if (number >= 0) {
        cout << "The number is positive or zero." << endl;
    } else {
        cout << "The number is negative." << endl;
    }
    
    return 0;
}
