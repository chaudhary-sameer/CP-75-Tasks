#include<iostream>
using namespace std;

int main() {
    int age;
    cout << "Enter your age: ";
    cin >> age;
    
    if (age >= 18 && age <= 65) {
        cout << "You fall within the standard working age bracket." << endl;
    }
    
    if (age < 18 || age > 65) {
        cout << "You are outside the standard working age bracket." << endl;
    }
    
    return 0;
}
