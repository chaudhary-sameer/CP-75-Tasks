#include <iostream>
using namespace std;
int main()
 {
    int marks;
    cout << "Enter your marks: ";
    cin >> marks;
    if (marks >= 50) 
        cout << "You passed.";
    if (marks < 50) 
        cout << "You failed.";
    return 0;
}