#include <iostream>
using namespace std;
int main()
 {
    int marks;
    cout << "Enter marks: ";
    cin >> marks;
    if (marks >= 80) 
        cout << "The student scored 80 or more marks.";
    else 
        cout << "The student scored less than 80 marks.";
    return 0;
}