#include <iostream>
using namespace std;
int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;
    if (num % 10 == 0)
        cout << "The number is a multiple of 10.";
    else 
        cout << "The number is not a multiple of 10.";
    return 0;
}