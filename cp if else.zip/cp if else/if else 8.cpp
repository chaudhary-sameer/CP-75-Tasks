#include <iostream>
using namespace std;
int main() 
{
    int num1, num2, num3;
    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;
    if (num1 == num2 && num2 == num3) 
        cout << "All three numbers are equal.";
    else if (num1 == num2) 
        cout << "The first and second numbers are equal.";
    else if (num1 == num3) 
        cout << "The first and third numbers are equal.";
    else if (num2 == num3) 
        cout << "The second and third numbers are equal.";
    else 
        cout << "All three numbers are different.";
    return 0;
}