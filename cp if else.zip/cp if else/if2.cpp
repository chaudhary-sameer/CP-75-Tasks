#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"enter a number";
	cin>>num;
	if 
	(num%2==0)
	cout<<"The number is even";
	if 
	(num%2!=0)
	cout<<"the number is odd";
	return 0;
}
	