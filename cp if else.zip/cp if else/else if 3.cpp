#include <iostream>
using namespace std;
int main() 
{
    int temperature;
    cout << "Enter temperature: ";
    cin >> temperature;
    if (temperature > 30) 
        cout << "The temperature is above 30 degrees.";
    else 
        cout << "The temperature is not above 30 degrees.";
    return 0;
}