#include <iostream>
using namespace std;
int main() 
{
    int age;
    cout << "Enter your age: ";
    cin >> age;
    if (age >= 18) 
        cout << "The person is an adult.";
    else 
        cout << "The person is a minor.";
    return 0;
}