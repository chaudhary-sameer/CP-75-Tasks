#include <iostream>
using namespace std;
int main()
 {
    int num;
    cout << "Enter a number: ";
    cin >> num;
    if (num >= 1 && num <= 50) 
        cout << "The number is within the range.";
    else 
        cout << "The number is outside the range.";
    return 0;
}