#include <iostream>
using namespace std;
int main() 
{
    int num1,num2;
    cout << "enter number: ";
    cin >> num1>>num2 ;
    if (num1 >num2)
        cout << "Number 1 is grater";
    if (num2 > num1)
        cout << "Number 2 is grater";
        if (num1 == num2) 
        cout << "Both numbers are equal.";
    return 0;
}