#include <iostream>
using namespace std;
int main()
{
    char light;
    cin >> light;
    switch(light)
    {
    case 'R':
    case 'r':
    cout << "Stop";
    break;
    case 'Y':
    case 'y':
    cout << "Wait";
    break;
    case 'G':
    case 'g':
    cout << "Go";
    break;
    default:
    cout << "Invalid Traffic Light";
    }
    return 0;
}