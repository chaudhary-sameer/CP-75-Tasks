#include <iostream>
using namespace std;
int main()
{
    char grade;
    cin >> grade;
    switch(grade)
    {
    case 'A':
    case 'a':
    cout << "Excellent";
    break;
    case 'B':
    case 'b':
    cout << "Very Good";
    break;
    case 'C':
    case 'c':
    cout << "Good";
    break;
    case 'D':
    case 'd':
    cout << "Needs Improvement";
    break;
    case 'F':
    case 'f':
    cout << "Fail";
    break;
        default:
            cout << "Invalid Grade";
    }
    return 0;
}