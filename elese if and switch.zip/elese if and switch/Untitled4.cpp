#include <iostream>
using namespace std;
int main()
{
    int choice;
    double radius, length, width, base, height;
    cout << "1. Circle" << endl;
    cout << "2. Rectangle" << endl;
    cout << "3. Triangle" << endl;
    cin >> choice;
    switch(choice)
    {
    case 1:
    cin >> radius;
    cout << "Area = " << 3.14159 * radius * radius;
    break;
    case 2:
    cin >> length >> width;
    cout << "Area = " << length * width;
    break;
    case 3:
    cin >> base >> height;
    cout << "Area = " << 0.5 * base * height;
    break;
    default:
     cout << "Invalid Choice";
    }

    return 0;
}