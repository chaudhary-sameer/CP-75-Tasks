#include <iostream>
using namespace std;
int main()
{
    double num1, num2;
    char op;
    cin >> num1 >> op >> num2;
    switch(op)
    {
        case '+':
            cout << "Result = " << num1 + num2;
            break;

        case '-':
            cout << "Result = " << num1 - num2;
            break;

        case '*':
            cout << "Result = " << num1 * num2;
            break;

        case '/':
            if(num2 != 0)
                cout << "Result = " << num1 / num2;
            else
                cout << "Cannot divide by zero";
            break;

        default:
            cout << "Invalid Operator";
    }
    return 0;
}