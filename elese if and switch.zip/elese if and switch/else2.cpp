#include <iostream>
using namespace std;
int main()
{
	int units;
	double bill;
	cout<<"enter your unit";
	cin>> units;
	if
	(units<=100)
	{
	bill=units*10;
	}
	else if
	(units<=200)
		{
	bill=units*15;
    }
	else if
	(units<=300){
	bill=units*20;
    }
	else
	{
    bill=units*25;
    }
     cout << "Total Bill = " << bill;
	return 0;
}