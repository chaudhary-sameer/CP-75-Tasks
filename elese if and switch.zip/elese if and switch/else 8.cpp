#include <iostream>
using namespace std;
int main()
{
    int speed;
    cin >> speed;
    if (speed <= 60)
    {
        cout << "No Fine";
    }
    else if (speed <= 80)
    {
        cout << "Fine = 1000";
    }
    else if (speed <= 100)
    {
        cout << "Fine = 2500";
    }
    else if (speed <= 120)
    {
        cout << "Fine = 5000";
    }
    else
    {
        cout << "License Suspended";
    }
    return 0;
}