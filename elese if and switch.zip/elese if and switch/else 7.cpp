#include <iostream>
using namespace std;
int main()
{
    double amount, discount, finalAmount;
    cin >> amount;
    if (amount >= 50000)
    {
        discount = amount * 0.20;
    }
    else if (amount >= 30000)
    {
        discount = amount * 0.15;
    }
    else if (amount >= 10000)
    {
        discount = amount * 0.10;
    }
    else
    {
        discount = amount * 0.05;
    }
    finalAmount = amount - discount;
    cout << "Discount = " << discount << endl;
    cout << "Final Amount = " << finalAmount;
    return 0;
}