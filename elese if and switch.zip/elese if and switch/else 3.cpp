#include <iostream>
using namespace std;
int main()
{
    int temp;
    cout<<"enter temperature :";
    cin >> temp;
    if (temp < 0)
    {
        cout << "Very Cold";
    }
    else if (temp <= 15)
    {
        cout << "Cold";
    }
    else if (temp <= 25)
    {
        cout << "Cool";
    }
    else if (temp <= 35)
    {
        cout << "Warm";
    }
    else
    {
        cout << "Hot";
    }

    return 0;
}