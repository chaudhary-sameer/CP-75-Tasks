#include <iostream>
using namespace std;
int main()
{
    int choice;
    double value;
    cout << "1. Kilometers to Meters" << endl;
    cout << "2. Meters to Centimeters" << endl;
    cout << "3. Kilograms to Grams" << endl;
    cout << "4. Hours to Minutes" << endl;
    cin >> choice;
    cin >> value;
    switch(choice)
    {
    case 1:
    cout << "Result = " << value * 1000 << " meters";
    break;
    case 2:
    cout << "Result = " << value * 100 << " centimeters";
    break;
    case 3:
    cout << "Result = " << value * 1000 << " grams";
    break;

    case 4:
    cout << "Result = " << value * 60 << " minutes";
    break;
    default:
    cout << "Invalid Choice";
    }
    return 0;
}