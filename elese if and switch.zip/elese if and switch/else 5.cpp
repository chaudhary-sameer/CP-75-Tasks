#include <iostream>
using namespace std;

int main()
{
    int age;
    int price;

    cin >> age;

    if (age < 12)
    {
        price = 300;
    }
    else if (age < 18)
    {
        price = 500;
    }
    else if (age < 60)
    {
        price = 800;
    }
    else
    {
        price = 400;
    }

    cout << "Ticket Price = " << price;

    return 0;
}