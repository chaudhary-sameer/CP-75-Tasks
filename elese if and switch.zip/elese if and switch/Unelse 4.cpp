#include <iostream>
using namespace std;
int main()
{
    double salary, bonus, finalSalary;
    int years;
    cout<<"enter salary ";
    cin >> salary ;
     cout<<"enter years ";
    cin >> years;
    if (years > 10)
    {
        bonus = salary * 0.20;
    }
    else if (years >= 5)
    {
        bonus = salary * 0.10;
    }
    else
    {
        bonus = salary * 0.05;
    }

    finalSalary = salary + bonus;
    cout << "Bonus = " << bonus << endl;
    cout << "Final Salary = " << finalSalary;
    return 0;
}