#include <iostream>
using namespace std;
int main()
{
    int choice;
    double balance = 50000;
    double amount;
    cout << "1. Check Balance" << endl;
    cout << "2. Deposit Money" << endl;
    cout << "3. Withdraw Money" << endl;
    cout << "4. Exit" << endl;
    cin >> choice;
    switch(choice)
    {
    case 1:
    cout << "Balance = " << balance;
    break;
    case 2:
    cin >> amount;
    balance = balance + amount;
    cout << "New Balance = " << balance;
    break;
    case 3:
    cin >> amount;
    if(amount <= balance)
    {
	balance = balance - amount;
    cout << "New Balance = " << balance;
    }
    else
    {
    cout << "Insufficient Balance";
    }
    break;
    case 4:
    cout << "Thank You";
    break;
    default:
    cout << "Invalid Choice";
    }
    return 0;
} 